from setuptools import setup

setup(
    name='vsearch',
    version='2.0',
    py_modules=['vsearch'],
)