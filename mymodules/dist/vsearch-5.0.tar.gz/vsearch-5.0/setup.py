from setuptools import setup

setup(
    name='vsearch',
    version='5.0',
    py_modules=['vsearch'],
)