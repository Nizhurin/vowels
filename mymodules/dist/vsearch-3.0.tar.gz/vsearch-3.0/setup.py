from setuptools import setup

setup(
    name='vsearch',
    version='3.0',
    py_modules=['vsearch'],
)