from setuptools import setup

setup(
    name='vsearch',
    version='4.0',
    py_modules=['vsearch'],
)