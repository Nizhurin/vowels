from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    py_modules=['vsearch'],
)